
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ddamato',
  applicationName: 'willarrive-in',
  appUid: 'Wh0gSPKCSPqHgjyCKB',
  orgUid: 'ThjQnHtzdB40cbGQrR',
  deploymentUid: '72bd5d81-b5c1-4aa8-9d3a-69a7b6bb9eb0',
  serviceName: 'willarrivein-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.0.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'willarrivein-service-dev-feed', timeout: 6 };

try {
  const userHandler = require('./api/feed.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}