
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ddamato',
  applicationName: 'willarrive-in',
  appUid: 'Wh0gSPKCSPqHgjyCKB',
  orgUid: 'ThjQnHtzdB40cbGQrR',
  deploymentUid: 'a5f14c31-b911-491a-8e96-e3891f0a7845',
  serviceName: 'willarrivein-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.0.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'willarrivein-service-dev-feed', timeout: 6 };

try {
  const userHandler = require('./api/feed.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}