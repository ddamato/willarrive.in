const { handler } = require('./api/domain.js');

const event = {
  requestContext: {
    domainPrefix: 'x',
  },
  queryStringParameters: {
    latitude: 40.759596,
    longitude: -73.830034,
    station: 'MTASBWY:A44',
  }
}

function callback(err, data) {
  console.log(data);
}

handler(event, null, callback);